<?php
if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use WHMCS\Database\Capsule;
//use GuzzleHttp\Client;

/**
 * @return array
 */
function paytr_MetaData()
{
    return array(
        'DisplayName' => 'PayTR Virtual Pos iFrame API (v9x)',
        'APIVersion' => '1.2'
    );
}

/**
 * @return array
 */
function paytr_config()
{
    return array(
        'FriendlyName' => array(
            'Type' => 'System',
            'Value' => 'PayTR Virtual Pos iFrame API (v9x)',
        ),
        'merchantID' => array(
            'FriendlyName' => 'Merchant ID',
            'Type' => 'text',
            'Size' => '20',
            'Default' => '',
            'Description' => 'Enter your <a href="https://www.paytr.com/magaza/bilgi" target="_blank">Merchant ID</a> here',
        ),
        'merchantKey' => array(
            'FriendlyName' => 'Merchant Key',
            'Type' => 'text',
            'Size' => '20',
            'Default' => '',
            'Description' => 'Enter your <a href="https://www.paytr.com/magaza/bilgi" target="_blank">Merchant Key</a> here',
        ),
        'merchantSalt' => array(
            'FriendlyName' => 'Merchant Salt',
            'Type' => 'text',
            'Size' => '20',
            'Default' => '',
            'Description' => 'Enter your <a href="https://www.paytr.com/magaza/bilgi" target="_blank">Merchant Salt</a> here',
        ),
        'iframe_v2_dark' => array(
            'FriendlyName' => 'iFrame v2 Dark Theme',
            'Type' => 'yesno',
            'Description' => 'Tick to enable dark theme for iFrame V2',
        ),
        'testMode' => array(
            'FriendlyName' => 'Test Mode',
            'Type' => 'yesno',
            'Description' => 'Tick to enable test mode',
        ),
        'lang' => array(
            'FriendlyName' => 'iFrame Language',
            'Type' => 'dropdown',
            'Options' => 'Turkish,English',
            'Description' => 'Set the language of the iframe page.',
            'Default' => 'Turkish',
        ),
    );
}

/**
 * @param array $params
 * @return string
 */
function paytr_link($params)
{
    $ip = '';

    if (php_sapi_name() !== 'cli') {
        if (!empty($_SERVER['HTTP_CLIENT_IP']) && filter_var($_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP)) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
        elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            $ipCandidate = trim($ips[0]);
            $ip = filter_var($ipCandidate, FILTER_VALIDATE_IP) ? $ipCandidate : $_SERVER['REMOTE_ADDR'];
        }
        elseif (!empty($_SERVER['REMOTE_ADDR'])) {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        else {
            $ip = '127.0.0.1';
        }
    }
    else {
        if (!empty($_SERVER['SERVER_ADDR']) && filter_var($_SERVER['SERVER_ADDR'], FILTER_VALIDATE_IP)) {
            $ip = $_SERVER['SERVER_ADDR'];
        }
        else {
            $hostIp = gethostbyname(gethostname());
            if ($hostIp && filter_var($hostIp, FILTER_VALIDATE_IP) && $hostIp !== gethostname()) {
                $ip = $hostIp;
            }
            else {
                $ip = '127.0.0.1';
            }
        }
    }

    $merchant_oid = 'SP' . $params['invoiceid'] . 'WHMCS' . time();
    $user_basket = base64_encode(json_encode([[$params['description'], $params['amount'], 1]]));
    $no_installment = 0;
    $max_installment = 0;
    $amount = round($params['amount'] * 100);
    $address1 = $params['clientdetails']['address1'] ?? '';
    $address2 = $params['clientdetails']['address2'] ?? '';
    $city = $params['clientdetails']['city'] ?? '';
    $state = $params['clientdetails']['state'] ?? '';
    $postcode = $params['clientdetails']['postcode'] ?? '';
    $country = $params['clientdetails']['country'] ?? '';
    $currency = $params['currency'] === 'TRY' ? 'TL' : ($params['currency'] ?? 'TL');
    $testmode = (!empty($params['testMode'])) ? 1 : 0;

    $hash_str = $params['merchantID'] . $ip . $merchant_oid . $params['clientdetails']['email'] . $amount . $user_basket . $no_installment . $max_installment . $currency . $testmode;
    $paytr_token = base64_encode(hash_hmac('sha256', $hash_str . $params['merchantSalt'], $params['merchantKey'], true));

    $post_vals = array(
        'merchant_id' => $params['merchantID'],
        'user_ip' => $ip,
        'merchant_oid' => $merchant_oid,
        'email' => $params['clientdetails']['email'],
        'payment_amount' => $amount,
        'paytr_token' => $paytr_token,
        'user_basket' => $user_basket,
        'debug_on' => 1,
        'no_installment' => $no_installment,
        'max_installment' => $max_installment,
        'user_name' => $params['clientdetails']['firstname'] . ' ' . $params['clientdetails']['lastname'],
        'user_address' => $address1 . ' ' . $address2 . ' ' . $city . ' ' . $state . ' ' . $postcode . ' ' . $country,
        'user_phone' => $params['clientdetails']['phonenumber'] ?? '',
        'merchant_ok_url' => $params['returnurl'],
        'merchant_fail_url' => $params['returnurl'],
        'timeout_limit' => 30,
        'currency' => $currency,
        'test_mode' => $testmode,
        'lang' => ($params['lang'] === 'Turkish') ? 'tr' : 'en',
        'iframe_v2_dark' => (!empty($params['iframe_v2_dark'])) ? 1 : 0,
    );

    $token = '';
    try {
        //$client = new Client();
        $client = new \GuzzleHttp\Client();
        $response = $client->post('https://www.paytr.com/odeme/api/get-token', [
            'form_params' => $post_vals,
            'timeout' => 20,
            'connect_timeout' => 10,
        ]);

        $result = json_decode($response->getBody()->getContents(), true);

        if ($result && isset($result['status']) && $result['status'] == 'success') {
            $token = $result['token'];
        }
        else {
            $reason = $result['reason'] ?? 'Unknown error';
            return '<div class="alert alert-danger">PAYTR IFRAME failed. Reason: ' . htmlspecialchars($reason) . '</div>';
        }
    }
    catch (\Exception $e) {
        return '<div class="alert alert-danger">PAYTR IFRAME connection error: ' . htmlspecialchars($e->getMessage()) . '</div>';
    }

    $iframeUrl = $params['systemurl'] . 'modules/gateways/callback/paytr_iframe.php?token=' . urlencode($token);

    return '<form method="post" action="' . $iframeUrl . '">
        <button type="submit" class="btn btn-primary">' . ($params['langpaynow'] ?? 'Pay Now') . '</button>
        <noscript>
            <div class="errorbox"><b>JavaScript is currently disabled or is not supported by your browser.</b><br />Please click the continue button to proceed with the processing of your transaction.</div>
            <p align="center"><input type="submit" value="Continue >>" /></p>
        </noscript>
    </form>';
}

/**
 * @param array $params
 * @return array
 */
function paytr_refund($params)
{
    $merchant_id = $params['merchantID'];
    $merchant_key = $params['merchantKey'];
    $merchant_salt = $params['merchantSalt'];
    $merchant_oid = $params['transid'];
    $return_amount = $params['amount'];

    $paytr_token = base64_encode(hash_hmac('sha256', $merchant_id . $merchant_oid . $return_amount . $merchant_salt, $merchant_key, true));

    $post_vals = array(
        'merchant_id' => $merchant_id,
        'merchant_oid' => $merchant_oid,
        'return_amount' => $return_amount,
        'paytr_token' => $paytr_token
    );

    try {
        $client = new Client();
        $response = $client->post('https://www.paytr.com/odeme/iade', [
            'form_params' => $post_vals,
            'timeout' => 90,
            'connect_timeout' => 30,
        ]);

        $result = json_decode($response->getBody()->getContents(), true);

        if ($result && isset($result['status']) && $result['status'] == 'success') {
            return array(
                'status' => 'success',
                'rawdata' => $result,
                'transid' => $result['merchant_oid'] ?? $merchant_oid,
                'fees' => $result['return_amount'] ?? $return_amount,
            );
        }
        else {
            $errMsg = $result['err_msg'] ?? 'Unknown error';
            return array(
                'status' => 'error',
                'rawdata' => $result,
            );
        }
    }
    catch (\Exception $e) {
        return array(
            'status' => 'error',
            'rawdata' => $e->getMessage(),
        );
    }
}
